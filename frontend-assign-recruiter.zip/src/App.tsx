import { useState, useMemo } from 'react';
import { Container, Box, ThemeProvider, createTheme } from '@mui/material';
import FilterBuilder from './components/FilterBuilder';
import DataTable from './components/DataTable';
import type { FilterCondition } from './types';
import { sampleEmployeeData, fieldDefinitions } from './data/sampleData';
import { applyFilters } from './utils/filterLogic';

const theme = createTheme({
  palette: {
    primary: {
      main: '#2196f3',
    },
    secondary: {
      main: '#f50057',
    },
  },
  typography: {
    fontFamily: '"Segoe UI", "Roboto", "Oxygen", "Ubuntu", "Cantarell", sans-serif',
  },
});

function App() {
  const [filters, setFilters] = useState<FilterCondition[]>([]);

  const filteredData = useMemo(() => {
    return applyFilters(sampleEmployeeData, filters);
  }, [filters]);

  return (
    <ThemeProvider theme={theme}>
      <Container maxWidth="lg" sx={{ py: 4 }}>
        <Box sx={{ mb: 4 }}>
          <h1 style={{ margin: '0 0 8px 0', fontSize: '2rem', color: '#333' }}>
            Dynamic Filter Component System
          </h1>
          <p style={{ margin: 0, color: '#666', fontSize: '1rem' }}>
            Real-time filtering of employee data with advanced filtering capabilities
          </p>
        </Box>

        <FilterBuilder
          filters={filters}
          onFiltersChange={setFilters}
          fieldDefinitions={fieldDefinitions}
        />

        <Box sx={{ backgroundColor: 'white', borderRadius: '4px' }}>
          <DataTable data={filteredData} totalRecords={sampleEmployeeData.length} />
        </Box>
      </Container>
    </ThemeProvider>
  );
}

export default App;
