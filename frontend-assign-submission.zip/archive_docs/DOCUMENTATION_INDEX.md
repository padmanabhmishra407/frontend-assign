```markdown
# Documentation Index (archived)

Index archived to reduce root clutter.

... (archived)

```