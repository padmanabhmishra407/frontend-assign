```markdown
# Architecture & Design Decisions (archived)

Full architecture document archived.

... (archived)

```