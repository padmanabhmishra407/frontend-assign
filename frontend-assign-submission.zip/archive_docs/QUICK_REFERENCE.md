```markdown
# Quick Reference (archived)

Quick reference archived.

... (archived)

```